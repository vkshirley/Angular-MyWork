package com.example.demoangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAngularApplication.class, args);
	}

}
